<?php


return [
    'View Dashboard',
    'Is Admin',

    //Activities
    'Manage Activities',

    //Users
    'Manage Users',
    'Create Users',
    'Edit Users',
    'Delete Users',

    //Roles
    'Manage Roles',
    'Create Roles',
    'Edit Roles',
    'Delete Roles',

    //Settings
    'Manage Settings',



];
