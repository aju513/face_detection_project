<?php

return[
    'status' => [
        1 => 'Active',
        0 => 'Inactive'
    ],
];
