<div class="mb-10">
    {{ $records->links('pagination::tailwind') }}
</div>
