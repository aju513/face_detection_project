import "../css/custom.css";
import "../css/style.css";
import "./main.js";
import "./defaultmenu.js";

import "./sticky.js";
import "./custom.js";
