<?php $__env->startSection('content'); ?>
<div class="main-content">
   <div class="p-6">
     Welcome, <?php echo e(auth()->user()->name); ?> !!!
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>