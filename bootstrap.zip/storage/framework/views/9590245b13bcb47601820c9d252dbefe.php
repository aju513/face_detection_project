<!-- Breadcrumb Start -->
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
    <nav>
        <ol class="flex gap-2 text-title-sm">
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard /</a></li>
            <li class="text-primary">
                <a href="<?php echo e(route('admin.'.$ui->route.'.index')); ?>"><?php echo e($title); ?></a>
            </li>
        </ol>
    </nav>
</div>
<!-- Breadcrumb End -->
<?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/admin/layouts/partials/breadcrumb.blade.php ENDPATH**/ ?>