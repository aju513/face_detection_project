<div class="grid grid-cols-12 gap-6">
    <div class="col-span-12">
        <div class="box">
            <div class="box-body p-0">
                <div class="overflow-auto">
                    <table class="ti-custom-table ti-custom-table-head ti-custom-table-hover">
                        <thead>
                            <tr class="font-bold">
                                <th scope="col">SN</th>
                                <?php $__currentLoopData = $ui->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th scope="col"><?php echo e($col); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($ui->getActions()) > 0): ?>
                                    <th scope="col" class="">
                                        Action
                                    </th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="font-bold"><?php echo e($records->firstItem() + $loop->index); ?>.</td>
                                    <?php $__currentLoopData = $ui->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="font-medium">
                                            <?php echo $ui->getAttribute($record, $attribute); ?>

                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($ui->getActions()) > 0): ?>
                                        <td class="font-medium">
                                            <div class="flex items-center gap-2">
                                                <?php $__currentLoopData = $ui->getActions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component => $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($action['permission'])): ?>
                                                        <?php echo $__env->first([
                                                            "admin.$view.actions.$component",
                                                            "admin.layouts.components.actions.$component",
                                                            'admin.layouts.components.actions.default',
                                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="<?php echo e(count($ui->columns) + 2); ?>" class="text-center py-3">
                                        No data found
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/admin/layouts/components/table.blade.php ENDPATH**/ ?>