<div id="loader">
    <img src="/img/media/loader.svg" alt="">
</div>
<?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/admin/layouts/partials/loader.blade.php ENDPATH**/ ?>