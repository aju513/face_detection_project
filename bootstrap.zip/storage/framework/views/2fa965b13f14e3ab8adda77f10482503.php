
<?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/admin/activities/search.blade.php ENDPATH**/ ?>