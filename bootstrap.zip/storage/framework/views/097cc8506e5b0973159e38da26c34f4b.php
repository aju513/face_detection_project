<div class="mb-10">
    <?php echo e($records->links('pagination::tailwind')); ?>

</div>
<?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/admin/layouts/components/pagination.blade.php ENDPATH**/ ?>