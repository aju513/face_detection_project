<footer class="mt-auto py-3 border-t dark:border-white/10 bg-white dark:bg-bgdark">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p class="text-center">Copyright © <span id="year"><?php echo e(date('Y')); ?></span> <a href="javascript:void(0)"
                class="text-primary">COL</a>. All rights reserved </p>
    </div>
</footer>
<?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/website/layouts/partials/footer.blade.php ENDPATH**/ ?>