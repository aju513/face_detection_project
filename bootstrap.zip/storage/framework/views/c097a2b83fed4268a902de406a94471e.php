<?php $__env->startSection('content'); ?>

    <div class="items-center w-full">
        <img src="<?php echo e(asset('img/col.png')); ?>" alt="" class="h-[500px] items-center">
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aju\Documents\niraksha\col-architecture\resources\views/website/home.blade.php ENDPATH**/ ?>