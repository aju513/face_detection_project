<?php $__env->startSection('content'); ?>
    <!-- Start::main-content -->
    <div class="main-content p-4 md:p-6 2xl:p-10">

        <div class="flex justify-between m-0 p-0">
            <?php echo $__env->make('admin.layouts.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.components.actions.create', ['action' => $ui->createAction()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
        <div class="my-3">
            <?php echo $__env->first(["admin.$view.search", 'admin.layouts.components.search'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- Start::row-2 -->
        <div class="flex flex-col gap-10">
            <?php echo $__env->make('admin.layouts.components.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.components.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- End::row-2-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/index.blade.php ENDPATH**/ ?>