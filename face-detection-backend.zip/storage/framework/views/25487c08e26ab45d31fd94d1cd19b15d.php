<a href="<?php echo e(route($action['route'], [$record->id] + $params)); ?>" data-tooltip="<?php echo e($action['placeholder'] ?? 'Edit'); ?>">
    <i class="<?php echo e($action['icon']); ?>"></i>
</a>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/components/actions/default.blade.php ENDPATH**/ ?>