<?php $__env->startSection('content'); ?>
    <div class="main-content overflow-y-scroll no-scrollbar mb-10 p-4 md:p-6 2xl:p-10">
        
        <?php echo $__env->make('admin.layouts.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Start::row-3 -->
        <div class="grid grid-cols-12 gap-x-6">
            <div class="col-span-12">
                <div class="box">
                    <div class="box-body">
                        <?php echo e(html()->modelForm($model, $ui->getMethod($model, $params), $ui->getRoute($model, $params))->id('form-validator')->acceptsFiles()->open()); ?>

                        <div class="row g-3">
                            <?php echo $__env->make($form, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <button type="submit" name="submit" value="SUBMIT" class="ti-btn ti-btn-primary">Submit</button>
                        <a type="button" class="ti-btn ti-btn-danger" href="<?php echo e(url()->previous()); ?>">Cancel</a>
                        <?php echo e(html()->closeModelForm()); ?>

                    </div>
                </div>
            </div>

        </div>
        <!-- End::row-3 -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/create.blade.php ENDPATH**/ ?>