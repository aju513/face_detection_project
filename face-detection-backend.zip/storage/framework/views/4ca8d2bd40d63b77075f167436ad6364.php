<button
    class="inline-flex rounded <?php echo e($model->status ? 'bg-emerald-700' : 'bg-danger'); ?> py-1 px-2 text-sm font-medium text-white hover:bg-opacity-90">
    <?php echo e(config('dropdown.status.' . $model->status)); ?>

</button>
<div class="bg-emerald-50"></div>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/components/status.blade.php ENDPATH**/ ?>