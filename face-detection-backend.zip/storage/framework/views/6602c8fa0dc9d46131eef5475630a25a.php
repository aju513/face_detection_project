<form action="<?php echo e(route($action['route'], [$record->id] + $params)); ?>" method="POST">   
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button data-tooltip="<?php echo e($action['placeholder'] ?? 'Delete'); ?>" type="submit" data-toggle="tooltip"
        class="text-danger bg-transparent border-0" data-placement="top"
        onclick="javascript:return confirm('Are you sure you want to delete?');">
        <i class="bi bi-trash"></i>
    </button>
</form>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/components/actions/delete.blade.php ENDPATH**/ ?>