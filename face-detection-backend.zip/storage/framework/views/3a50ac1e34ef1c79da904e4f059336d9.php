<?php if($action): ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($action['permission'])): ?>
        <a href="<?php echo e(route($action['route'], $params)); ?>"
            class="inline-flex items-center justify-center rounded-md border bg-primary py-2 px-5 text-white text-center text-xl font-medium  hover:bg-blue-500 hover:text-white lg:px-5 xl:px-5">
            <i class="bi bi-plus me-2"></i>
           Add
        </a>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/components/actions/create.blade.php ENDPATH**/ ?>