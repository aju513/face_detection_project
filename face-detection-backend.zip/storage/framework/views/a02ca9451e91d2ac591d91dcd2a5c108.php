<?php $list_helper = app('App\Helpers\ListHelper'); ?>


<!-- Teacher Selection -->
<div class="mb-4.5 w-full">
    <?php echo e(html()->label('Teacher(*)')->for('teacher_id')->class('mb-2.5 block text-black dark:text-white')); ?>

    <?php echo e(html()->select('teacher_id')->options($list_helper->teachers())->placeholder('Select a teacher...')->value('')->class('ti-form-select py-2 px-3')); ?>

    <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'teacher_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- Student Selection -->
<div class="mb-4.5 w-full">
    <?php echo e(html()->label('Student(*)')->for('student_id')->class('mb-2.5 block text-black dark:text-white')); ?>

    <?php echo e(html()->select('student_id')->options($list_helper->students())->placeholder('Select a student...')->value('')->class('ti-form-select py-2 px-3')); ?>

    <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'student_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- Faculty Selection -->
<div class="mb-4.5 w-full">
    <?php echo e(html()->label('Faculty(*)')->for('faculty_id')->class('mb-2.5 block text-black dark:text-white')); ?>

    <?php echo e(html()->select('faculty_id')->options($list_helper->faculties())->placeholder('Select a faculty...')->value('')->class('ti-form-select py-2 px-3')); ?>

    <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'faculty_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- Start Time -->
<div class="mb-4.5 w-full">
    <?php echo e(html()->label('Start Time(*)')->for('start_time')->class('mb-2.5 block text-black dark:text-white')); ?>

    <?php echo e(html()->text('start_time')->type('time')->value(old('start_time'))->class('ti-form-input py-2 px-3')); ?>

    <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'start_time'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- End Time -->
<div class="mb-4.5 w-full">
    <?php echo e(html()->label('End Time(*)')->for('end_time')->class('mb-2.5 block text-black dark:text-white')); ?>

    <?php echo e(html()->text('end_time')->type('time')->value(old('end_time'))->class('ti-form-input py-2 px-3')); ?>

    <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'end_time'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/assign-students/form.blade.php ENDPATH**/ ?>