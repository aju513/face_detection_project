<div id="loader">
    <img src="/img/media/loader.svg" alt="">
</div>
<?php /**PATH D:\7thSem\face-detection-backend\resources\views/admin/layouts/partials/loader.blade.php ENDPATH**/ ?>