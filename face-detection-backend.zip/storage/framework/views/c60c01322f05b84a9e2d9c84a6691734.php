<script src="<?php echo e(asset('customjs/switch.js')); ?>"></script>


<?php echo $__env->make('admin.layouts.components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\7thSem\face-detection-backend\resources\views/admin/layouts/partials/scripts.blade.php ENDPATH**/ ?>