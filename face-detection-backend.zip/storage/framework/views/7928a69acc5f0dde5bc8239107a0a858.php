<?php $teacher_helper = app('App\Helpers\TeacherHelper'); ?>
<?php $subject_helper = app('App\Helpers\SubjectHelper'); ?>
<div class="grid grid-cols-2 gap-5">

    <!-- Teacher ID Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Teacher (*)')->for('teacher_id')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->select('teacher_id')->options($teacher_helper->dropdown())->placeholder('Select a teacher...')->required()->class('ti-form-select py-2 px-3' . ($errors->has('teacher_id') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'teacher_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Subject ID Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Subject (*)')->for('subject_id')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->select('subject_id')->options($subject_helper->dropdown())->placeholder('Select a subject...')->required()->class('ti-form-select py-2 px-3' . ($errors->has('subject_id') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'subject_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Days of Week Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Days of Week (*)')->for('days_of_week')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->select('days_of_week[]')->options(config('dropdown.weeks'))->multiple()->placeholder('Select days...')->required()->class('ti-form-select py-2 px-3' . ($errors->has('days_of_week') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'days_of_week'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Start Time Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Start Time (*)')->for('start_time')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->time('start_time')->placeholder('Start Time')->required()->class('ti-form-select' . ($errors->has('start_time') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'start_time'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- End Time Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('End Time (*)')->for('end_time')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->time('end_time')->placeholder('End Time')->required()->class('ti-form-select' . ($errors->has('end_time') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'end_time'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/teacher-subjects/form.blade.php ENDPATH**/ ?>