<?php if(session('message')): ?>
    <script>
        var message = <?php echo json_encode(session('message'), 15, 512) ?>;
        toastr.success(message, 'Success', {
            closeButton: true,
            progressBar: true,
            positionClass: "toast-top-right", // Position: top-right, you can change it to "toast-bottom-left", etc.
            timeOut: "3000", // Duration of the toast (in milliseconds)
        });
    </script>
<?php endif; ?>
<?php if(session('error')): ?>
    <script>
        var errorMessage = <?php echo json_encode(session('error'), 15, 512) ?>;
        toastr.success(errorMessage, 'Error', {
            closeButton: true,
            progressBar: true,
            positionClass: "toast-top-right", // Position: top-right, you can change it to "toast-bottom-left", etc.
            timeOut: "3000", // Duration of the toast (in milliseconds)
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/components/alerts.blade.php ENDPATH**/ ?>