<aside class="app-sidebar" id="sidebar">

    <!-- Start::main-sidebar-header -->
    <div class="main-sidebar-header">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="header-logo">
            <img src="<?php echo e(asset('img/col-h.png')); ?>" alt="logo" class="main-logo desktop-logo" style="max-height: 50px;">
            <img src="<?php echo e(asset('img/col.png')); ?>" alt="logo" class="main-logo toggle-logo ">
            <img src="<?php echo e(asset('img/col-hw.png')); ?>" alt="logo" class="main-logo desktop-dark" style="max-height: 50px;">
            <img src="<?php echo e(asset('img/col.png')); ?>" alt="logo" class="main-logo toggle-dark">
        </a>
    </div>
    <!-- End::main-sidebar-header -->

    <!-- Start::main-sidebar -->
    <div class="main-sidebar " id="sidebar-scroll">

        <!-- Start::nav -->
        <nav class="main-menu-container nav nav-pills flex-column sub-open">
            <div class="slide-left" id="slide-left"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191"
                    width="24" height="24" viewBox="0 0 24 24">
                    <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path>
                </svg></div>
            <ul class="main-menu">
                <!-- Start::slide__category -->
                <li class="slide__category"><span class="category-name">Menu</span></li>
                <!-- End::slide__category -->
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Start::slide -->
                <li class="slide">
                    <?php if($parent_menu->children->count() > 0): ?>
                        
                        
                        <!-- Start::slide -->
                        <li class="slide  has-sub">
                            <a href="javascript:void(0);" class="side-menu__item">
                                <i class="<?php echo e($parent_menu->icon); ?>"></i>
                                <span class="side-menu__label"><?php echo e($parent_menu->display_name); ?></span>
                                <i class="ri ri-arrow-right-s-line side-menu__angle"></i>
                            </a>
                            <ul class="slide-menu child1">
                                <?php $__currentLoopData = $parent_menu->children->where('status', 1)->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($child_menu->permission)): ?>
                                <li class="slide">
                                    <a href="<?php echo e($child_menu->route == '#' ? '#' : route($child_menu->route)); ?>" class="side-menu__item">
                                        <?php echo e($child_menu->display_name); ?>

                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <!-- End::slide -->
                    <?php else: ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($parent_menu->permission)): ?>
                            <a href="<?php echo e($parent_menu->route == '#' ? '#' : route($parent_menu->route)); ?>"
                                class="side-menu__item">
                                <i class="<?php echo e($parent_menu->icon); ?>"></i>
                                <span class="side-menu__label"> <?php echo e($parent_menu->display_name); ?></span>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </li>
                <!-- End::slide -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="slide-right" id="slide-right"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191"
                    width="24" height="24" viewBox="0 0 24 24">
                    <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path>
                </svg></div>
        </nav>
        <!-- End::nav -->

    </div>
    <!-- End::main-sidebar -->

</aside>
<?php /**PATH D:\7thSem\face-detection-backend\resources\views/admin/layouts/partials/sidebar.blade.php ENDPATH**/ ?>