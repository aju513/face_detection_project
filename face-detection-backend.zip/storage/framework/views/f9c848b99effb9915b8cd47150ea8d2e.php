<div class="grid grid-cols-2 gap-5">

    <!-- Name Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Name (*)')->for('name')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->text('name')->placeholder('Name')->required()->class('ti-form-select' . ($errors->has('name') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Code Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Code (*)')->for('code')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->text('code')->placeholder('Code')->required()->class('ti-form-select' . ($errors->has('code') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/subjects/form.blade.php ENDPATH**/ ?>