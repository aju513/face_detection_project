<?php $student_helper = app('App\Helpers\StudentHelper'); ?>
<div class="grid grid-cols-2 gap-5">

    <!-- Student Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Student (*)')->for('student_id')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->select('student_id')->options($student_helper->dropdown())->placeholder('Select a student...')->required()->class('ti-form-select' . ($errors->has('student_id') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'student_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Teacher Subject Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Teacher Subject (*)')->for('teacher_subject_id')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->select('teacher_subject_id')->options($student_helper->teacherSubjects())->placeholder('Select a teacher subject...')->required()->class('ti-form-select' . ($errors->has('teacher_subject_id') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'teacher_subject_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/student-subjects/form.blade.php ENDPATH**/ ?>