<div class="grid grid-cols-1 md:grid-cols-2 gap-5">
    <!-- Name Input -->
    <div>
        <?php echo e(html()->label('Name')->class('mb-2 font-semibold text-black dark:text-white')); ?>

        <span class="text-red-500">*</span>
        <?php echo e(html()->text('name')->placeholder('Enter Name')->required(true)->class('ti-form-input' . ($errors->has('name') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/faculties/form.blade.php ENDPATH**/ ?>