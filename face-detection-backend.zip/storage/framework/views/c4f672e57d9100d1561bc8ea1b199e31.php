<?php if($model->searchable): ?>
    <?php echo e(Form::open(['url' => url()->current(),'method' => 'GET'])); ?>

    <div class="form-row">
        <div class="col-md-4 form-group">
            <?php echo e(Form::select('types[]',$model->searchable,null,[
            'class' => 'form-control '
            ])); ?>

        </div>
        <div class="col-md-4 form-group">
            <?php echo e(Form::text('values[]',null,[
            'class' => 'form-control '
            ])); ?>

        </div>
        <div class="col-md-4 form-group">
            <?php echo e(Form::submit('Search',[
            'class' => 'btn btn-success'
            ])); ?>

            <a href="<?php echo e(route(Request::route()->getName())); ?>" class="btn btn-info">Refresh</a>
        </div>
    </div>
    <?php echo e(Form::close()); ?>

<?php endif; ?>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/components/search.blade.php ENDPATH**/ ?>