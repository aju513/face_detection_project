<?php $role_helper = app('App\Helpers\RoleHelper'); ?>

<div class="grid grid-cols-2 gap-5">

    <!-- Name Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Name (*)')->for('name')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->text('name')->placeholder('Name')->required()->class('ti-form-select' . ($errors->has('name') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Email Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Email (*)')->for('email')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->email('email')->placeholder('email@example.com')->required()->class('ti-form-select' . ($errors->has('email') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php if(!$model->exists): ?>
        <!-- Password Field -->
        <div class="mb-4.5 w-full">
            <?php echo e(html()->label('Password (*)')->for('password')->class('mb-2.5 block text-black dark:text-white')); ?>

            <?php echo e(html()->password('password')->placeholder('Password')->required()->class('ti-form-select' . ($errors->has('password') ? ' is-invalid' : ''))); ?>

            <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- Confirm Password Field -->
        <div class="mb-4.5 w-full">
            <?php echo e(html()->label('Confirm Password (*)')->for('password_confirmation')->class('mb-2.5 block text-black dark:text-white')); ?>

            <?php echo e(html()->password('password_confirmation')->placeholder('Confirm Password')->required()->class('ti-form-select' . ($errors->has('password_confirmation') ? ' is-invalid' : ''))); ?>

            <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'password_confirmation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>

    <!-- Designation Field -->
    <div class="mb-4.5 w-full">
        <?php echo e(html()->label('Designation')->for('designation')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->text('designation')->placeholder('Designation')->class('ti-form-select' . ($errors->has('designation') ? ' is-invalid' : ''))); ?>

        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'designation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Roles Field -->
    <div class="mb-4.5 w-full mb-2">
        <?php echo e(html()->label('Roles (*)')->for('roles[]')->class('mb-2.5 block text-black dark:text-white')); ?>

        <?php echo e(html()->select('roles')->options($role_helper->dropdown())->placeholder('Select a roles...')->value(isset($model->roles()->first()->id) ? $model->roles()->first()->id : '')->class('ti-form-select py-2 px-3' . ($errors->has('roles') ? ' is-invalid' : ''))); ?>


        <?php echo $__env->make('admin.layouts.components.validation', ['name' => 'roles'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>
<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/users/form.blade.php ENDPATH**/ ?>