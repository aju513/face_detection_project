<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($action['permission'])): ?>
    <a data-tooltip="<?php echo e($action['placeholder'] ?? 'Change Status'); ?>" type="button" href="<?php echo e(route($action['route'],[$record->id] + $params)); ?>" data-toggle="tooltip" class="text-<?php echo e($record->status ? 'emerald-600' : 'danger'); ?>" data-placement="top">
        <i class="<?php echo e($record->status  ? 'bi bi-check-circle' : 'bi bi-x-circle'); ?>"></i>
    </a>
<?php endif; ?>


<?php /**PATH C:\Users\Aju\Documents\FinalYearProject\face\col-architecture\resources\views/admin/layouts/components/actions/status.blade.php ENDPATH**/ ?>