<?php

return [
    'status' => [
        1 => 'Active',
        0 => 'Inactive'
    ],
    'social_media' => [
        1 => 'Facebook',
        2 => 'Instagram'
    ],
    'weeks' => [
        1 => 'Monday',
        2 => 'Tuesday',
        3 => 'Wednesday',
        4 => 'Thursday',
        5 => 'Friday',
        6 => 'Saturday',
        7 => 'Sunday'
    ]
];
