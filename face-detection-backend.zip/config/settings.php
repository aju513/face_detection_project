<?php


return [
    [
        'name' => 'general-settings',
        'display_name' => 'General Settings',
        'permission' => 'Manage Settings',
        'display_order' => 1
    ],
];
