<?php


return [
    'View Dashboard',
    'Is Admin',

    //Activities
    'Manage Activities',

    //Users
    'Manage Users',
    'Create Users',
    'Edit Users',
    'Delete Users',

    //Roles
    'Manage Roles',
    'Create Roles',
    'Edit Roles',
    'Delete Roles',

    //Settings
    'Manage Settings',
    'Manage Personal Settings',
    'Manage Account Settings',
    'Manage Password Settings',

    //Roles
    'Manage Teachers',
    'Create Teachers',
    'Edit Teachers',
    'Delete Teachers',

    //Students
    'Manage Students',
    'Create Students',
    'Edit Students',
    'Delete Students',

    //Subject
    'Manage Subject',
    'Create Subject',
    'Edit Subject',
    'Delete Subject',

    //StudentSubject
    'Manage StudentSubject',
    'Create StudentSubject',
    'Edit StudentSubject',
    'Delete StudentSubject',

    //TeacherSubject
    'Manage TeacherSubject',
    'Create TeacherSubject',
    'Edit TeacherSubject',
    'Delete TeacherSubject',

    //Attendance
    'Manage Attendance',
    'Create Attendance',
    'Edit Attendance',
    'Delete Attendance',

    //Reschedule
    'Manage Reschedule',
    'Create Reschedule',
    'Edit Reschedule',
    'Delete Reschedule',


];
