<button
    class="inline-flex rounded bg-{{ $online ? 'success' : 'danger' }} py-1 px-2 text-sm font-medium text-white hover:bg-opacity-90">
    {{ $online ? 'Online' : 'Offline' }}
</button>
