<div id="loader">
    <img src="/img/media/loader.svg" alt="">
</div>
