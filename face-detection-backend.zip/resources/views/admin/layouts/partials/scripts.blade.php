<script src="{{ asset('customjs/switch.js') }}"></script>
{{-- <script src="{{ asset('customjs/custom.js') }}"></script> --}}
{{-- <script src="{{ asset('customjs/defaultmenu.js') }}"></script> --}}
@include('admin.layouts.components.alerts')
