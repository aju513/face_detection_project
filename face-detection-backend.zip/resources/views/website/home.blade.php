
@extends('website.layouts.default')

@section('content')

    <div class="items-center w-full">
        <img src="{{asset('img/col.png')}}" alt="" class="h-[500px] items-center">
    </div>


@endsection
